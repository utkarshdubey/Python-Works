file = open("hi.txt", "a")
file.write("Hello World")
file.close()



# Methods
# w, +w
# r, +r
# a -> append