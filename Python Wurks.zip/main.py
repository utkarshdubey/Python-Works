input_number = input("Please enter a fekking number! ")
reversed_number = str((input_number)[::-1])
if input_number == reversed_number:
	print("This is a palindrome numver")
else:
	print("f o ")