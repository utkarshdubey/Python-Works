text = "Hello Miya Kaise Ho. Kya karriye ho?"

for letter in list(text):
	print(letter)